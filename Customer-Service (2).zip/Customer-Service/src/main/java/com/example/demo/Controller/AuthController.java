
package com.example.demo.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Repository.CustomerRepository;
import com.example.demo.Service.CustomerService;
import com.example.demo.entity.AuthenticationRequest;
import com.example.demo.entity.AuthenticationResponse;
import com.example.demo.entity.Customer;
import com.example.demo.entity.JwtUtils;

@RestController
public class AuthController {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtUtils jwtUtils;
	
	@Autowired
	private RestTemplate template;
	
	//GET COMAPANY DETAILS FROM COMPANY SERVICE
	
	@RequestMapping("/company/customer")
	public String getAllCompany()
	{
		String url="http://localhost:8093/company";
		return template.getForObject(url, String.class);
	}

	
	@GetMapping("/dashboard")
	private String testingToken()
	{
		return "<h1>Welcome to Dashboard<h1>"; 
	}
	
	@PostMapping("/subs")
	private ResponseEntity<?> subscribeClient(@RequestBody AuthenticationRequest authenticationRequest)
	{
		String username=authenticationRequest.getUsername();
		String password=authenticationRequest.getPassword();
		Customer customer=new Customer();
		customer.setUsername(username);
		customer.setPassword(password);
		 
		try {
			customerRepository.save(customer);
			}
		catch(Exception e)
		{
			return ResponseEntity.ok(new AuthenticationResponse("Error during subscription"+username));	
		}
		
		return ResponseEntity.ok(new AuthenticationResponse("Successfully subcribed "+username));
	}
	
	
	
	 
	@PostMapping("/auth")
	private ResponseEntity<?> authenticateClient(@RequestBody AuthenticationRequest authenticationRequest)
	{
		

		String username=authenticationRequest.getUsername();
		String password=authenticationRequest.getPassword();
		try
		{
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username,password));
		}
		catch(Exception e)
		{
		return ResponseEntity.ok(new AuthenticationResponse("Error during authentication"+username));
		}
		
		UserDetails loadedUser=customerService.loadUserByUsername(username);
		
		String generatedToken=jwtUtils.generateToken(loadedUser);

		return ResponseEntity.ok(new AuthenticationResponse(generatedToken ));
		//return ResponseEntity.ok(new AuthenticationResponse("Successfully subcribed "+username));
	
}
}