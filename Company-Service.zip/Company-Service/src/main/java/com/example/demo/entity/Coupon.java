package com.example.demo.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



public class Coupon {



	private String code;   //amazoncode orflipkart code
	private  String discount;  //50%  or based on users



	private  String expDate;   //date 



	public String getCode() {
		return code;
	}



	public void setCode(String code) {
		this.code = code;
	}



	public String getDiscount() {
		return discount;
	}



	public void setDiscount(String discount) {
		this.discount = discount;
	}



	public String getExpDate() {
		return expDate;
	}



	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}



	public Coupon(String code, String discount, String expDate) {

		this.code = code;
		this.discount = discount;
		this.expDate = expDate;
	}



	public Coupon() {

	}



	@Override
	public String toString() {
		return "Coupon [code=" + code + ", discount=" + discount + ", expDate=" + expDate + "]";
	}





}
